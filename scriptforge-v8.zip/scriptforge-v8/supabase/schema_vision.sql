-- ============================================================
-- SCRIPTFORGE VISION ENGINE — SCHEMA EXTENSION
-- Run this AFTER the main schema.sql
-- Adds clip indexing, vector search, and editor project tables
-- ============================================================

-- Enable pgvector for semantic clip search
create extension if not exists vector;

-- ============================================================
-- CLIP INDEX
-- One record per clip, per user. Stores visual + audio vectors,
-- transcripts, and semantic tags extracted during indexing.
-- ============================================================

create table clip_index (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id) on delete set null,

  -- File identity (from File System Access API)
  filename        text not null,
  filepath        text not null,             -- relative path from footage root
  file_size       bigint,
  file_modified_at bigint,                   -- File.lastModified (ms epoch) for change detection
  duration_ms     int,                        -- milliseconds
  width           int,
  height          int,
  fps             numeric(6,3),
  codec           text,

  -- Clip type
  clip_type       text default 'cam',         -- 'cam' | 'daw' | 'broll' | 'unknown'

  -- AI-extracted content
  transcript      text,                       -- Whisper STT output
  visual_tags     text[],                     -- CLIP zero-shot labels
  dominant_emotion text,                      -- detected face/scene emotion
  audio_energy    numeric(4,3),               -- 0.0–1.0 RMS energy level
  scene_type      text,                       -- 'talking-head' | 'daw-screen' | 'broll' | 'mixed'
  thumbnail_b64   text,                       -- base64 frame thumbnail (small, for UI)

  -- Vectors (CLIP visual embedding + text embedding)
  visual_vector   vector(512),                -- CLIP ViT-B/32 embedding
  text_vector     vector(384),                -- all-MiniLM-L6-v2 transcript embedding

  -- Indexing state
  indexed_at      timestamptz,
  index_version   int default 1,
  needs_reindex   boolean default false,

  created_at      timestamptz default now(),
  updated_at      timestamptz default now(),

  unique(user_id, filepath)
);

alter table clip_index enable row level security;

create policy "Users can CRUD own clip index"
  on clip_index for all using (auth.uid() = user_id);

-- Vector search indexes (IVFFlat for approximate nearest neighbour)
create index idx_clip_visual_vector on clip_index
  using ivfflat (visual_vector vector_cosine_ops) with (lists = 50);

create index idx_clip_text_vector on clip_index
  using ivfflat (text_vector vector_cosine_ops) with (lists = 50);

create index idx_clip_user_category on clip_index(user_id, category_id);
create index idx_clip_type on clip_index(clip_type);
create index idx_clip_needs_reindex on clip_index(user_id) where needs_reindex = true;

-- ============================================================
-- EDITOR PROJECTS
-- One per episode. Stores the virtual timeline as JSON,
-- AI flags, approved cuts, and export history.
-- ============================================================

create table editor_projects (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id) on delete set null,
  episode_id      uuid references episodes(id) on delete set null,

  name            text not null,
  footage_root    text,                       -- last-used footage folder path hint

  -- Timeline state
  timeline        jsonb default '[]',         -- array of TimelineClip objects
  duration_ms     int default 0,

  -- AI output
  ai_draft        jsonb default '[]',         -- original AI-assembled draft
  ai_flags        jsonb default '[]',         -- { clipId, type, reason, suggestion }
  ai_confidence   numeric(4,3),               -- 0.0–1.0 overall assembly confidence

  -- User decisions
  approved_cuts   jsonb default '[]',         -- clips user confirmed
  rejected_cuts   jsonb default '[]',         -- clips user swapped out
  swap_history    jsonb default '[]',         -- { original, replacement, reason }

  -- Export
  last_exported_at timestamptz,
  export_format   text,                       -- 'fcpxml' | 'otio' | 'edl'
  export_path     text,

  status          text default 'draft',       -- 'draft' | 'ai_assembled' | 'in_review' | 'approved' | 'exported'

  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table editor_projects enable row level security;

create policy "Users can CRUD own editor projects"
  on editor_projects for all using (auth.uid() = user_id);

create index idx_editor_user on editor_projects(user_id);
create index idx_editor_episode on editor_projects(episode_id);

-- ============================================================
-- INDEXING JOBS
-- Tracks the state of batch clip indexing runs.
-- ============================================================

create table indexing_jobs (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id),

  status          text default 'pending',     -- 'pending' | 'running' | 'complete' | 'failed'
  total_clips     int default 0,
  indexed_clips   int default 0,
  failed_clips    int default 0,
  error_log       jsonb default '[]',

  started_at      timestamptz,
  completed_at    timestamptz,
  created_at      timestamptz default now()
);

alter table indexing_jobs enable row level security;

create policy "Users can manage own indexing jobs"
  on indexing_jobs for all using (auth.uid() = user_id);

-- ============================================================
-- SEMANTIC SEARCH FUNCTION
-- Call from backend: match clips by visual + text vector similarity
-- ============================================================

create or replace function match_clips(
  p_user_id        uuid,
  p_query_vector   vector(512),
  p_text_vector    vector(384),
  p_visual_weight  float default 0.6,
  p_text_weight    float default 0.4,
  p_match_count    int default 5,
  p_category_id    uuid default null,
  p_clip_type      text default null
)
returns table (
  id              uuid,
  filename        text,
  filepath        text,
  clip_type       text,
  transcript      text,
  visual_tags     text[],
  dominant_emotion text,
  audio_energy    numeric,
  scene_type      text,
  thumbnail_b64   text,
  duration_ms     int,
  combined_score  float
)
language plpgsql as $$
begin
  return query
  select
    c.id,
    c.filename,
    c.filepath,
    c.clip_type,
    c.transcript,
    c.visual_tags,
    c.dominant_emotion,
    c.audio_energy,
    c.scene_type,
    c.thumbnail_b64,
    c.duration_ms,
    (
      p_visual_weight * (1 - (c.visual_vector <=> p_query_vector)) +
      p_text_weight   * (1 - (c.text_vector   <=> p_text_vector))
    )::float as combined_score
  from clip_index c
  where
    c.user_id = p_user_id
    and c.indexed_at is not null
    and (p_category_id is null or c.category_id = p_category_id)
    and (p_clip_type is null or c.clip_type = p_clip_type)
  order by combined_score desc
  limit p_match_count;
end;
$$;

-- ============================================================
-- UPDATED_AT TRIGGER for new tables
-- ============================================================

create trigger update_clip_index_updated_at before update on clip_index
  for each row execute procedure update_updated_at();

create trigger update_editor_projects_updated_at before update on editor_projects
  for each row execute procedure update_updated_at();
