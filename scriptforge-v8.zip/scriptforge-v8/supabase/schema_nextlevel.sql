-- ============================================================
-- SCRIPTFORGE NEXT LEVEL — SCHEMA EXTENSION
-- Run this AFTER schema.sql and schema_vision.sql
-- Adds: session journals, retention model data, alignment data
-- ============================================================

-- ── Add retention curve map to existing episodes table ───────────────────────
alter table episodes
  add column if not exists retention_curve_map  jsonb,   -- parsed YT retention curve { "0": 100, "30": 82, ... }
  add column if not exists retention_patterns   jsonb,   -- extracted structural patterns { cuts, recoveries, peaks }
  add column if not exists alignment_data       jsonb;   -- Whisper word-level timestamps after VO recording

-- ── SESSION JOURNALS ─────────────────────────────────────────────────────────
-- One record per recording session (companion app).
-- Stores raw utterances + timestamps that become the voice memo.

create table session_journals (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id) on delete set null,
  episode_id      uuid references episodes(id) on delete set null,

  -- Session metadata
  title           text,
  recorded_at     timestamptz default now(),
  duration_ms     int,

  -- Raw journal entries (array of timestamped utterances)
  entries         jsonb default '[]',
  -- Each entry: { id, timestamp_ms, text, type: 'speech'|'marker'|'note', energy: 0-1 }

  -- Processed outputs
  transcript      text,           -- full cleaned transcript
  key_moments     jsonb,          -- extracted key moments with timestamps
  voice_memo_text text,           -- Claude-synthesised voice memo ready for episode generation

  -- Sync state
  synced_to_episode boolean default false,
  status          text default 'recording',  -- 'recording' | 'processing' | 'ready' | 'used'

  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table session_journals enable row level security;

create policy "Users can CRUD own session journals"
  on session_journals for all using (auth.uid() = user_id);

create index idx_sessions_user on session_journals(user_id);
create index idx_sessions_episode on session_journals(episode_id);
create index idx_sessions_status on session_journals(user_id, status);

-- ── RETENTION MODEL DATA ─────────────────────────────────────────────────────
-- Training examples for the personal retention classifier.
-- One row per (clip, vo_segment) pair with known retention outcome.

create table retention_model_data (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id) on delete set null,
  episode_id      uuid references episodes(id) on delete set null,
  clip_id         uuid references clip_index(id) on delete set null,

  -- Features
  visual_vector   vector(512),        -- CLIP embedding of the clip
  text_vector     vector(384),        -- MiniLM embedding of the VO segment
  audio_energy    numeric(4,3),       -- clip audio energy level
  clip_type       text,               -- 'cam' | 'daw' | 'broll'
  timeline_position numeric(5,3),     -- 0.0-1.0 position in episode
  vo_segment      text,               -- the VO line playing over this clip

  -- Labels (from actual retention data)
  retention_delta  numeric(6,3),      -- % change in retention at this moment (-100 to +100)
  retained         boolean,           -- simplified: did retention hold (delta > -5)?

  -- Model version
  model_version   int default 1,
  created_at      timestamptz default now()
);

alter table retention_model_data enable row level security;

create policy "Users can CRUD own retention model data"
  on retention_model_data for all using (auth.uid() = user_id);

create index idx_retmodel_user_cat on retention_model_data(user_id, category_id);
create index idx_retmodel_retained on retention_model_data(user_id, retained);

-- Vector indexes for model training queries
create index idx_retmodel_visual on retention_model_data
  using ivfflat (visual_vector vector_cosine_ops) with (lists = 20);

-- ── UPDATED_AT TRIGGERS ───────────────────────────────────────────────────────
create trigger update_session_journals_updated_at before update on session_journals
  for each row execute procedure update_updated_at();
