-- ============================================================
-- SCRIPTFORGE SOUND LIBRARY — SCHEMA EXTENSION
-- Run after schema_nextlevel.sql
-- Adds: sound library, sound assets, episode sound placements
-- ============================================================

-- ── SOUND LIBRARY ────────────────────────────────────────────────────────────
-- One per user/category. The bucket that all sounds belong to.

create table sound_libraries (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id) on delete set null,
  name            text not null default 'My Sound Library',
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table sound_libraries enable row level security;
create policy "Users can CRUD own sound libraries"
  on sound_libraries for all using (auth.uid() = user_id);

-- ── SOUND ASSETS ─────────────────────────────────────────────────────────────
-- Each uploaded sound file. Stored in Supabase Storage.
-- Tagged semantically so the system can select them intelligently.

create table sound_assets (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  library_id      uuid not null references sound_libraries(id) on delete cascade,

  -- Identity
  name            text not null,
  filename        text not null,
  storage_path    text not null,      -- supabase storage path: {user_id}/sounds/{filename}
  duration_ms     int,
  file_size       bigint,
  mime_type       text,

  -- Classification
  asset_type      text not null,
  -- 'music_bed'     — full background music track (30s–3min)
  -- 'sting'        — short punctuation sound (0.5s–5s)
  -- 'transition'   — scene change sound (1s–8s)
  -- 'atmosphere'   — ambient background texture (loopable)
  -- 'sfx'          — spot sound effect
  -- 'intro_jingle' — branded intro sound
  -- 'outro_jingle' — branded outro sound

  -- Mood/energy tags (used for intelligent selection)
  mood_tags       text[] default '{}',
  -- e.g. ['melancholic', 'late-night', 'focused', 'lo-fi']

  energy_level    numeric(3,2),       -- 0.0 (silent/ambient) to 1.0 (intense)
  bpm             int,                -- for music beds — null for non-rhythmic assets

  -- Usage tracking
  use_count       int default 0,
  last_used_at    timestamptz,

  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table sound_assets enable row level security;
create policy "Users can CRUD own sound assets"
  on sound_assets for all using (auth.uid() = user_id);

create index idx_sound_assets_library  on sound_assets(library_id);
create index idx_sound_assets_type     on sound_assets(asset_type);
create index idx_sound_assets_mood     on sound_assets using gin(mood_tags);

-- ── EPISODE SOUND PLACEMENTS ──────────────────────────────────────────────────
-- The actual sound design for one episode.
-- Claude selects assets from the library and places them at timecodes.
-- This gets exported as part of the EDL.

create table episode_sound_placements (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  episode_id      uuid not null references episodes(id) on delete cascade,

  -- Each placement: one sound asset at one position
  asset_id        uuid references sound_assets(id) on delete set null,
  asset_name      text,               -- denormalised for display even if asset deleted

  track           text not null,      -- 'A1' (VO), 'A2' (music), 'A3' (sfx), 'A4' (atmos)
  is_locked       boolean default false,  -- locked placements survive re-runs of sound design
  rec_in_ms       int not null,       -- placement position in ms from episode start
  rec_out_ms      int,                -- null = play to end of asset
  fade_in_ms      int default 0,
  fade_out_ms     int default 500,
  volume_db       numeric(5,2) default 0.0,   -- dB adjustment from nominal

  -- Claude's reasoning for this placement
  placement_note  text,

  created_at      timestamptz default now()
);

alter table episode_sound_placements enable row level security;
create policy "Users can CRUD own sound placements"
  on episode_sound_placements for all using (auth.uid() = user_id);

create index idx_sound_placements_episode on episode_sound_placements(episode_id);

-- ── UPDATED_AT TRIGGERS ───────────────────────────────────────────────────────
create trigger update_sound_libraries_updated_at before update on sound_libraries
  for each row execute procedure update_updated_at();
create trigger update_sound_assets_updated_at before update on sound_assets
  for each row execute procedure update_updated_at();
