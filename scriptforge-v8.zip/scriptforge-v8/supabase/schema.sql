-- ============================================================
-- SCRIPTFORGE — SUPABASE SCHEMA
-- Run this in Supabase SQL Editor to initialise the database.
-- All tables use RLS. Users only see their own data.
-- Categories are the top-level isolation unit within a user account.
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm"; -- for text search

-- ============================================================
-- ENUMS
-- ============================================================

create type subscription_tier as enum ('free', 'pro', 'studio');
create type vault_entry_type as enum ('hook', 'script', 'trending', 'shortform', 'concept', 'successful');
create type episode_status as enum ('draft', 'generating', 'ready', 'recorded', 'published');
create type refresh_trigger as enum ('app_open', 'category_switch', 'manual', 'scheduled');

-- ============================================================
-- PROFILES
-- Extends Supabase auth.users with app-specific data.
-- Created automatically on signup via trigger.
-- ============================================================

create table profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  email           text,
  display_name    text,
  avatar_url      text,
  tier            subscription_tier default 'free',

  -- Rental / multi-tenant metadata
  is_admin        boolean default false,
  invited_by      uuid references profiles(id),
  invite_code     text unique,
  max_categories  int default 3,       -- tier-gated: free=3, pro=10, studio=unlimited
  max_episodes_pm int default 8,       -- max episode generations per month

  -- Usage tracking
  episodes_this_month int default 0,
  usage_reset_at  timestamptz default date_trunc('month', now()) + interval '1 month',

  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table profiles enable row level security;

create policy "Users can read own profile"
  on profiles for select using (auth.uid() = id);

create policy "Users can update own profile"
  on profiles for update using (auth.uid() = id);

create policy "Admins can read all profiles"
  on profiles for select using (
    exists (select 1 from profiles where id = auth.uid() and is_admin = true)
  );

-- ============================================================
-- CATEGORIES
-- Each category is an isolated creative context.
-- Music doc, client fitness brand, client tech — all separate.
-- ============================================================

create table categories (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,

  name            text not null,
  niche           text not null,
  description     text,
  color           text default '#6366f1',   -- UI accent colour per category
  icon            text default 'film',       -- lucide icon name

  -- Voice + format config (stored as JSON blobs, loaded into Claude context)
  voice_profile          jsonb,
  format_bible           jsonb,
  retention_db           jsonb,
  retention_template     jsonb,           -- cached from retentionMapper.buildRetentionTemplate()
  retention_template_at  timestamptz,     -- when the template was last built

  -- Refresh tracking
  trending_refreshed_at   timestamptz,
  trending_data           jsonb,
  competitors_refreshed_at timestamptz,

  -- Smart refresh config
  refresh_interval_hours  int default 48,
  auto_refresh_enabled    boolean default true,

  -- Category-level stats
  total_episodes  int default 0,
  avg_retention   numeric(5,2),

  is_active       boolean default true,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table categories enable row level security;

create policy "Users can CRUD own categories"
  on categories for all using (auth.uid() = user_id);

create index idx_categories_user_id on categories(user_id);

-- ============================================================
-- EPISODES
-- One record per generated episode package.
-- ============================================================

create table episodes (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid not null references categories(id) on delete cascade,

  episode_number  int not null,
  slug            text not null,
  status          episode_status default 'draft',

  -- Track metadata
  track_name      text not null,
  track_mood      text,
  track_genre     text,
  track_bpm       int,
  track_platform_link text,

  -- Voice memo input
  voice_memo_text text,

  -- Generation outputs (stored as text, files in Storage)
  vo_script       text,
  edl_clip_map    text,
  metadata_block  jsonb,   -- title, description, tags, chapters, tiktok_caption
  short_form_moments jsonb,
  episode_concept text,
  retention_curve jsonb,   -- energy/mood scoring per minute

  -- Generation decisions (for feedback loop)
  generation_decisions jsonb,

  -- File storage paths (Supabase Storage)
  edl_file_path      text,
  vo_script_path     text,
  sound_brief_path   text,
  shorts_path        text,
  metadata_path      text,

  -- Performance data (filled in after publishing)
  yt_view_count       int,
  yt_avg_view_pct     numeric(5,2),
  yt_retention_score  numeric(5,2),
  tt_view_count       int,
  tt_full_watch_rate  numeric(5,2),
  performance_logged_at timestamptz,

  published_at    timestamptz,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now(),

  unique(user_id, category_id, episode_number)
);

alter table episodes enable row level security;

create policy "Users can CRUD own episodes"
  on episodes for all using (auth.uid() = user_id);

create index idx_episodes_user_category on episodes(user_id, category_id);
create index idx_episodes_status on episodes(status);
create index idx_episodes_created_at on episodes(created_at desc);

-- ============================================================
-- VAULT ENTRIES
-- Ideas, hooks, scripts, trending angles — all saved here.
-- ============================================================

create table vault_entries (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id) on delete set null,
  episode_id      uuid references episodes(id) on delete set null,

  type            vault_entry_type not null,
  title           text not null,
  content         text not null,
  tags            text[] default '{}',
  is_favourite    boolean default false,
  used_at         timestamptz,

  -- Performance data if this idea was used and performed well
  performance     jsonb,  -- { views, retentionPct, platform, score }

  -- Search vector for full-text search
  search_vector   tsvector generated always as (
    to_tsvector('english', coalesce(title,'') || ' ' || coalesce(content,''))
  ) stored,

  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table vault_entries enable row level security;

create policy "Users can CRUD own vault entries"
  on vault_entries for all using (auth.uid() = user_id);

create index idx_vault_user_category on vault_entries(user_id, category_id);
create index idx_vault_type on vault_entries(type);
create index idx_vault_favourite on vault_entries(user_id, is_favourite) where is_favourite = true;
create index idx_vault_search on vault_entries using gin(search_vector);
create index idx_vault_tags on vault_entries using gin(tags);

-- ============================================================
-- SERIES MEMORY
-- One record per episode in the series index.
-- Used to give Claude memory across episodes.
-- ============================================================

create table series_memory (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid not null references categories(id) on delete cascade,
  episode_id      uuid references episodes(id) on delete set null,

  episode_number  int not null,
  episode_slug    text not null,
  track_name      text,
  track_context   jsonb,

  summary         text,
  key_moments     text[],
  themes          text[],
  callback_seeds  text[],

  performance     jsonb,
  published_at    timestamptz,

  created_at      timestamptz default now(),
  updated_at      timestamptz default now(),

  unique(user_id, category_id, episode_number)
);

alter table series_memory enable row level security;

create policy "Users can CRUD own series memory"
  on series_memory for all using (auth.uid() = user_id);

create index idx_series_user_category on series_memory(user_id, category_id);

-- ============================================================
-- GENERATION LOG
-- Records every generation decision + eventual performance.
-- Powers the feedback loop and Claude correlation analysis.
-- ============================================================

create table generation_log (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid not null references categories(id) on delete cascade,
  episode_id      uuid references episodes(id) on delete set null,

  episode_slug    text,
  episode_number  int,
  track_context   jsonb,
  decisions       jsonb,   -- hook type, intercut rhythm, trending angle, etc.

  performance     jsonb,   -- filled in when analytics arrive
  insights        text,    -- Claude's analysis of this entry vs others

  generated_at    timestamptz default now(),
  performance_logged_at timestamptz
);

alter table generation_log enable row level security;

create policy "Users can CRUD own generation log"
  on generation_log for all using (auth.uid() = user_id);

create index idx_genlog_user_category on generation_log(user_id, category_id);
create index idx_genlog_has_performance on generation_log(user_id) where performance is not null;

-- ============================================================
-- ANALYTICS UPLOADS
-- Each CSV upload creates one record with parsed results.
-- ============================================================

create table analytics_uploads (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid not null references categories(id) on delete cascade,

  platform        text not null,   -- 'youtube' | 'tiktok'
  upload_date     timestamptz default now(),
  video_count     int,
  avg_score       numeric(5,2),
  top_performers  jsonb,           -- array of top video objects
  insights        text,            -- Claude's interpretation
  raw_data        jsonb,           -- full parsed data

  created_at      timestamptz default now()
);

alter table analytics_uploads enable row level security;

create policy "Users can CRUD own analytics"
  on analytics_uploads for all using (auth.uid() = user_id);

create index idx_analytics_user_category on analytics_uploads(user_id, category_id);
create index idx_analytics_platform on analytics_uploads(user_id, platform);

-- ============================================================
-- REFRESH LOG
-- Tracks every trending/competitor refresh for smart staleness.
-- ============================================================

create table refresh_log (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid not null references categories(id) on delete cascade,

  refresh_type    text not null,   -- 'trending' | 'competitors' | 'voice_profile'
  trigger         refresh_trigger default 'manual',
  duration_ms     int,
  video_count     int,
  success         boolean default true,
  error_message   text,

  created_at      timestamptz default now()
);

alter table refresh_log enable row level security;

create policy "Users can read own refresh log"
  on refresh_log for all using (auth.uid() = user_id);

-- ============================================================
-- COLLABORATION SESSIONS
-- Real-time co-generation sessions between users.
-- ============================================================

create table collab_sessions (
  id              uuid primary key default uuid_generate_v4(),
  owner_id        uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id),
  episode_id      uuid references episodes(id),

  session_code    text unique default substr(md5(random()::text), 1, 8),
  is_active       boolean default true,
  participants    jsonb default '[]',   -- array of { user_id, role, joined_at }

  created_at      timestamptz default now(),
  expires_at      timestamptz default now() + interval '24 hours'
);

alter table collab_sessions enable row level security;

create policy "Owner can manage collab sessions"
  on collab_sessions for all using (auth.uid() = owner_id);

create policy "Participants can read sessions they joined"
  on collab_sessions for select using (
    participants @> jsonb_build_array(jsonb_build_object('user_id', auth.uid()::text))
  );

-- ============================================================
-- CHAT HISTORY
-- Persists Claude conversation threads per mode + session.
-- ============================================================

create table chat_history (
  id              uuid primary key default uuid_generate_v4(),
  user_id         uuid not null references profiles(id) on delete cascade,
  category_id     uuid references categories(id),
  episode_id      uuid references episodes(id),

  mode            text not null,   -- 'generate' | 'vault' | 'series' | 'analytics' | 'sound'
  messages        jsonb default '[]',  -- array of { role, content, timestamp }
  context_summary text,               -- compressed summary of old messages for long threads

  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

alter table chat_history enable row level security;

create policy "Users can CRUD own chat history"
  on chat_history for all using (auth.uid() = user_id);

create index idx_chat_user_mode on chat_history(user_id, mode);
create index idx_chat_episode on chat_history(episode_id);

-- ============================================================
-- INVITE CODES
-- For renting out / inviting users.
-- ============================================================

create table invite_codes (
  id              uuid primary key default uuid_generate_v4(),
  code            text unique not null default substr(md5(random()::text), 1, 12),
  created_by      uuid not null references profiles(id),
  used_by         uuid references profiles(id),
  tier            subscription_tier default 'pro',
  max_uses        int default 1,
  use_count       int default 0,
  expires_at      timestamptz default now() + interval '30 days',
  created_at      timestamptz default now()
);

alter table invite_codes enable row level security;

create policy "Admins can manage invite codes"
  on invite_codes for all using (
    exists (select 1 from profiles where id = auth.uid() and is_admin = true)
  );

create policy "Anyone can read unused invite codes by code"
  on invite_codes for select using (use_count < max_uses and expires_at > now());

-- ============================================================
-- STORAGE BUCKETS
-- Run these in Supabase Storage settings or via CLI.
-- ============================================================

-- insert into storage.buckets (id, name, public) values
--   ('episode-outputs', 'episode-outputs', false),
--   ('analytics-uploads', 'analytics-uploads', false),
--   ('voice-profiles', 'voice-profiles', false);

-- Storage RLS: users can only access their own files
-- File path convention: {user_id}/{category_id}/{episode_slug}/{filename}

-- ============================================================
-- FUNCTIONS + TRIGGERS
-- ============================================================

-- Auto-create profile on signup
create or replace function handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- Auto-update updated_at timestamps
create or replace function update_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger update_profiles_updated_at before update on profiles
  for each row execute procedure update_updated_at();
create trigger update_categories_updated_at before update on categories
  for each row execute procedure update_updated_at();
create trigger update_episodes_updated_at before update on episodes
  for each row execute procedure update_updated_at();
create trigger update_vault_updated_at before update on vault_entries
  for each row execute procedure update_updated_at();
create trigger update_chat_updated_at before update on chat_history
  for each row execute procedure update_updated_at();

-- Auto-increment category episode count
create or replace function increment_category_episode_count()
returns trigger language plpgsql as $$
begin
  update categories
  set total_episodes = total_episodes + 1
  where id = new.category_id;
  return new;
end;
$$;

create trigger on_episode_created
  after insert on episodes
  for each row execute procedure increment_category_episode_count();

-- Reset monthly usage counter
create or replace function reset_monthly_usage()
returns void language plpgsql as $$
begin
  update profiles
  set episodes_this_month = 0,
      usage_reset_at = date_trunc('month', now()) + interval '1 month'
  where usage_reset_at <= now();
end;
$$;

-- ============================================================
-- TIER FEATURE GATES (helper function)
-- Call this from the backend to check if a user can do something.
-- ============================================================

create or replace function check_tier_limit(p_user_id uuid, p_action text)
returns jsonb language plpgsql security definer as $$
declare
  v_profile profiles%rowtype;
  v_cat_count int;
begin
  select * into v_profile from profiles where id = p_user_id;

  if p_action = 'generate_episode' then
    if v_profile.episodes_this_month >= v_profile.max_episodes_pm then
      return jsonb_build_object('allowed', false, 'reason', 'Monthly episode limit reached. Upgrade to generate more.');
    end if;
    return jsonb_build_object('allowed', true);
  end if;

  if p_action = 'create_category' then
    select count(*) into v_cat_count from categories where user_id = p_user_id and is_active = true;
    if v_cat_count >= v_profile.max_categories then
      return jsonb_build_object('allowed', false, 'reason', 'Category limit reached for your plan. Upgrade to add more.');
    end if;
    return jsonb_build_object('allowed', true);
  end if;

  if p_action = 'series_memory' then
    return jsonb_build_object('allowed', v_profile.tier in ('pro', 'studio'));
  end if;

  if p_action = 'generation_log' then
    return jsonb_build_object('allowed', v_profile.tier in ('pro', 'studio'));
  end if;

  if p_action = 'collab' then
    return jsonb_build_object('allowed', v_profile.tier = 'studio');
  end if;

  return jsonb_build_object('allowed', true);
end;
$$;

-- ============================================================
-- INCREMENT EPISODES THIS MONTH (atomic counter)
-- Called from episodes.js after every successful generation.
-- Uses UPDATE with arithmetic to avoid read-modify-write race.
-- Also handles monthly reset if the reset_at date has passed.
-- ============================================================

create or replace function increment_episodes_this_month(p_user_id uuid)
returns void language plpgsql security definer as $$
begin
  -- Reset counter if we've crossed the monthly boundary
  update profiles
  set
    episodes_this_month = 0,
    usage_reset_at      = date_trunc('month', now()) + interval '1 month'
  where id = p_user_id
    and usage_reset_at <= now();

  -- Atomic increment
  update profiles
  set episodes_this_month = episodes_this_month + 1
  where id = p_user_id;
end;
$$;
